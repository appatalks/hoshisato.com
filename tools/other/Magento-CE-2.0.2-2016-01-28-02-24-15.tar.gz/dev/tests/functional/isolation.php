<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

//Isolation script sample
//exec('mysql -uroot -p123123q -e"DROP DATABASE mtf; CREATE DATABASE mtf CHARACTER SET utf8;"');
//exec('mysql -uroot -p123123q mtf < /var/www/mtf/mtf.dump.sql');
//exec('rm -rf /var/www/mtf/var/*');
